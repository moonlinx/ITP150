"""
hello_world.py
@author: Devin Delaney
Created September 5, 2024
This script prints "Hello World!" to the console
"""


print("Hello World!")
