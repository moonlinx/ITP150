import sys

locate_python = sys.executable

print(locate_python)
